# Cobra Net API

API d'administration pour Cobra Net VPN : gestion des profils Xray et de leur
expiration, pensée pour être appelée par l'app Android (ÉTAPE 9 du projet).

## 1. Créer la base de données (Neon)

1. Compte sur https://neon.tech (gratuit, sans carte bancaire).
2. Créer un projet → copier la chaîne de connexion fournie.
3. Ouvrir l'éditeur SQL de Neon, coller et exécuter le contenu de
   `migrations/schema.sql`.

## 2. Générer les secrets

```bash
npm install
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"   # -> JWT_SECRET
node scripts/hash-password.js "votre-mot-de-passe-admin"                   # -> ADMIN_PASSWORD_HASH
```

Ne mettez jamais le mot de passe en clair ni ces valeurs dans le code ou sur GitHub.

## 3. Déployer sur Render

1. Poussez ce dossier dans un dépôt GitHub.
2. Sur https://render.com → New + → Web Service → sélectionnez le dépôt.
3. Build Command : `npm install` — Start Command : `node server.js`.
4. Dans l'onglet **Environment**, ajoutez :
   - `DATABASE_URL` (celle de Neon)
   - `JWT_SECRET` (générée à l'étape 2)
   - `ADMIN_USERNAME` (ex: `admin`)
   - `ADMIN_PASSWORD_HASH` (générée à l'étape 2)
5. Déployez. Render vous donne une URL du type `https://cobra-net-api.onrender.com`.

Le plan gratuit met le service en veille après ~15 min d'inactivité : le
premier appel après une pause prend 20-30 secondes, les suivants sont normaux.

## 4. Tester

```bash
# Connexion
curl -X POST https://VOTRE-URL.onrender.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"votre-mot-de-passe-admin"}'
# -> {"token": "...", "expiresIn": "12h"}

# Liste des profils (avec le token reçu ci-dessus)
curl https://VOTRE-URL.onrender.com/api/profiles \
  -H "Authorization: Bearer LE_TOKEN"
```

## Endpoints

| Méthode | Route                        | Description                          |
|---------|-------------------------------|---------------------------------------|
| POST    | /api/auth/login               | Authentification, retourne un JWT     |
| GET     | /api/profiles                 | Liste des profils                     |
| GET     | /api/profiles/:id              | Détail d'un profil                    |
| POST    | /api/profiles                 | Créer un profil                       |
| PUT     | /api/profiles/:id              | Modifier un profil                    |
| DELETE  | /api/profiles/:id              | Supprimer un profil                   |
| POST    | /api/profiles/:id/renew        | Prolonger l'expiration (`extraDays`)  |

Toutes les routes `/api/profiles/*` exigent l'en-tête
`Authorization: Bearer <token>` obtenu via `/api/auth/login`.

## Prochaine étape côté app Android

Cette API existe maintenant indépendamment de l'app. Pour la relier :
remplacer `LocalStubCloudExportProvider` par une vraie implémentation de
`CloudExportProvider` qui appelle ces endpoints (avec Retrofit ou
`HttpURLConnection`) — c'était prévu dès l'ÉTAPE 2 pour que ce changement
n'affecte aucun autre fichier de l'app.
