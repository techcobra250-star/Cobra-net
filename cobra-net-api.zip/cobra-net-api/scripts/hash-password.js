// Usage : node scripts/hash-password.js "votre-mot-de-passe"
// Copiez le résultat dans la variable d'environnement ADMIN_PASSWORD_HASH.
// Le mot de passe en clair n'est jamais stocké nulle part après ça.
const bcrypt = require('bcryptjs');

const plainPassword = process.argv[2];
if (!plainPassword) {
    console.error('Usage : node scripts/hash-password.js "votre-mot-de-passe"');
    process.exit(1);
}

const hash = bcrypt.hashSync(plainPassword, 12);
console.log('ADMIN_PASSWORD_HASH=' + hash);
