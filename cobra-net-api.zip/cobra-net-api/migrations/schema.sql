-- À exécuter une fois dans l'éditeur SQL de Neon (ou via psql) avant le
-- premier déploiement. Reflète les mêmes entités que la base Room locale
-- de l'app Android (ClientEntity, VpnProfileEntity), pour rester cohérent.

CREATE TABLE IF NOT EXISTS clients (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT,
    client_code TEXT NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vpn_profiles (
    id SERIAL PRIMARY KEY,
    client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    xray_json TEXT NOT NULL,
    display_server TEXT,
    display_port INTEGER,
    display_protocol TEXT,
    activation_date TIMESTAMPTZ NOT NULL DEFAULT now(),
    expiration_date TIMESTAMPTZ NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_vpn_profiles_client_id ON vpn_profiles(client_id);
